Hi,
I have number scripts according the section number and lecture number. Please note, that lecture number might be during time not right in case new lecture will be added to the course - but I'm not afraid that you wouldn't find what you need :) 

Richard